package com.kritikachugh.cache.factories;

import com.kritikachugh.cache.Cache;
import com.kritikachugh.cache.policies.LRUEvictionPolicy;
import com.kritikachugh.cache.storage.HashMapBasedStorage;

public class CacheFactory<Key, Value> {

    public Cache<Key, Value> defaultCache(final int capacity) {
        return new Cache<Key, Value>(new LRUEvictionPolicy<Key>(),
                new HashMapBasedStorage<Key, Value>(capacity));
    }
}
