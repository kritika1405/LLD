package com.kritikachugh.algoritms.exceptions;

public class InvalidNodeException extends RuntimeException {
}
